/* =========================================================================
   TapEasy — ACCENT THEO THEME (theme-accent.js) · đi kèm theme-accent.css · docs/THEME-PACKS.md §8
   Nạp ngay sau theme-packs.js (trước ui-signature.js / health-safety.js). Việc của file:
   1. LOGO ĐỔI MÀU THEO THEME: thay <img src="assets/brand/logo-wordmark-*.svg | logo-lockup-*.svg | logo-mark.svg">
      bằng SVG NỘI TUYẾN (cùng path của file gốc — file logo gốc KHÔNG sửa) có 2 nhóm màu:
        .ta-tap  → fill:var(--logo-text)   (chữ "Tap")
        .ta-easy / .ta-mark → fill:var(--logo-mark) (chữ "Easy" + biểu tượng)
      → đổi theme = đổi biến CSS → logo đổi màu TỨC THÌ, không tải lại, không đổi DOM.
      Ảnh cặp bản nền sáng (.on-light, aria-hidden) bị gỡ vì SVG nội tuyến tự đổi màu theo nền.
      Fallback: JS lỗi/tắt → <img> gốc vẫn hiển thị (logo teal như cũ). Bỏ qua: [data-ta-keep], Cửa hàng (.tsx), Quản trị (.adm).
   2. Theo dõi DOM (MutationObserver) để logo do màn chào / menu / splash / onboarding vẽ lại sau này cũng được thay.
   API: window.teAccent = { logoSVG(kind, cls, label), swapLogos(root), tokens(), KINDS }
   Tắt (thử nghiệm): window.TE_ACCENT_OFF = { logo:1 } trước khi nạp.
   ========================================================================= */
(function(){
  "use strict";
  const OFF = window.TE_ACCENT_OFF || {};
  /* path đo từ assets/brand/logo-wordmark-light.svg (viewBox 0 0 770.2 180.6) và logo-mark.svg (0 0 200 134) */
  const TAP = "<path d=\"M0 0 L116.8 0 L116.8 28.2 L74.5 28.2 L74.5 141.9 L42.3 141.9 L42.3 28.2 L0 28.2 Z\"/><path d=\"M145.17 36.06 Q156.21 36.06 164.53 40.55 Q172.85 45.03 177.34 52.33 L177.34 37.55 L209.31 37.55 L209.31 141.9 L177.34 141.9 L177.34 127.13 Q172.66 134.42 164.34 138.91 Q156.02 143.4 144.99 143.4 Q132.27 143.4 121.8 136.76 Q111.33 130.12 105.25 117.87 Q99.17 105.62 99.17 89.54 Q99.17 73.46 105.25 61.3 Q111.33 49.15 121.8 42.6 Q132.27 36.06 145.17 36.06 ZM154.52 63.92 Q144.99 63.92 138.35 70.75 Q131.71 77.57 131.71 89.54 Q131.71 101.51 138.35 108.52 Q144.99 115.53 154.52 115.53 Q164.06 115.53 170.7 108.61 Q177.34 101.69 177.34 89.73 Q177.34 77.76 170.7 70.84 Q164.06 63.92 154.52 63.92 Z\"/><path d=\"M290.54 36.06 Q303.44 36.06 313.92 42.6 Q324.39 49.15 330.47 61.3 Q336.54 73.46 336.54 89.54 Q336.54 105.62 330.47 117.87 Q324.39 130.12 313.92 136.76 Q303.44 143.4 290.54 143.4 Q279.7 143.4 271.37 138.91 Q263.05 134.42 258.38 127.31 L258.38 179.8 L226.4 179.8 L226.4 37.55 L258.38 37.55 L258.38 52.33 Q263.05 45.03 271.28 40.55 Q279.51 36.06 290.54 36.06 ZM281 63.92 Q271.47 63.92 264.83 70.84 Q258.19 77.76 258.19 89.73 Q258.19 101.69 264.83 108.61 Q271.47 115.53 281 115.53 Q290.54 115.53 297.27 108.52 Q304.01 101.51 304.01 89.54 Q304.01 77.57 297.37 70.75 Q290.73 63.92 281 63.92 Z\"/>";
  const EASY = "<path d=\"M352.6 0 L449.8 0 L449.8 26.8 L384.2 26.8 L384.2 57.4 L442.8 57.4 L442.8 83 L384.2 83 L384.2 115.3 L450.6 115.3 L450.6 141.9 L352.6 141.9 Z\"/><path d=\"M503.06 36.06 Q514.1 36.06 522.42 40.55 Q530.74 45.03 535.23 52.33 L535.23 37.55 L567.21 37.55 L567.21 141.9 L535.23 141.9 L535.23 127.13 Q530.55 134.42 522.23 138.91 Q513.91 143.4 502.88 143.4 Q490.16 143.4 479.69 136.76 Q469.22 130.12 463.14 117.87 Q457.06 105.62 457.06 89.54 Q457.06 73.46 463.14 61.3 Q469.22 49.15 479.69 42.6 Q490.16 36.06 503.06 36.06 ZM512.41 63.92 Q502.88 63.92 496.24 70.75 Q489.6 77.57 489.6 89.54 Q489.6 101.51 496.24 108.52 Q502.88 115.53 512.41 115.53 Q521.95 115.53 528.59 108.61 Q535.23 101.69 535.23 89.73 Q535.23 77.76 528.59 70.84 Q521.95 63.92 512.41 63.92 Z\"/><path d=\"M590.84 110.56 L576.51 127.56 C595.2 151.56 663.19 151.8 662.91 112.44 C662.77 92.21 646.42 84.52 629.21 80.45 C623.18 79.03 612.83 78.1 608.63 73.17 C603.37 67 610.47 60.9 616.59 60.05 C627.32 58.56 635.49 63.34 644.34 68.64 L658.91 52.94 C639.62 26.81 576.52 32.42 579.09 72.31 C580.28 90.95 597.66 97.41 613.21 101.03 C619.67 102.53 628.98 103.35 633.29 109.05 C639.3 116.99 629.51 120.9 622.84 121.54 C610.95 122.68 600.41 117.06 590.96 110.65 Z\"/><path d=\"M662.9 39.4 L693.8 39.4 L717.4 107.81 L740.8 39.4 L770.2 39.4 L728.92 149 C720.92 170.27 712.5 180.6 689.4 180.6 L675.7 180.6 L675.7 155.8 L685.4 155.8 C703.14 155.8 703.71 141.84 698.6 129 Z\"/>";
  const MARK = "<rect x=\"0\" y=\"16\" width=\"18\" height=\"72\" rx=\"9\"/><rect x=\"24\" y=\"0\" width=\"26\" height=\"104\" rx=\"13\"/><rect x=\"56\" y=\"42\" width=\"88\" height=\"20\" rx=\"10\"/><rect x=\"150\" y=\"0\" width=\"26\" height=\"104\" rx=\"13\"/><rect x=\"182\" y=\"16\" width=\"18\" height=\"72\" rx=\"9\"/><circle cx=\"100\" cy=\"90.8\" r=\"11\"/><path d=\"M89.17 112.78 C74.75 123.89 57.49 131.24 39.38 133.4 C34.53 133.98 24.78 134.68 20.22 133.38 C22.75 132.74 25.52 132.72 28.12 132.38 C32.56 131.8 36.97 131.01 41.31 129.93 C57.34 125.97 72.29 118.27 84.72 107.38 C86.21 106.15 88.41 106.37 89.64 107.86 C90.87 109.35 90.66 111.55 89.17 112.78 Z\"/><path d=\"M110.83 112.78 C125.25 123.89 142.51 131.24 160.62 133.4 C165.47 133.98 175.22 134.68 179.78 133.38 C177.25 132.74 174.48 132.72 171.88 132.38 C167.44 131.8 163.03 131.01 158.69 129.93 C142.66 125.97 127.71 118.27 115.28 107.38 C113.79 106.15 111.59 106.37 110.36 107.86 C109.13 109.35 109.34 111.55 110.83 112.78 Z\"/>";
  const KINDS = {
    wordmark:{ vb:"0 0 770.2 180.6", w:770.2, h:180.6, body:()=> `<g class="ta-tap" fill-rule="evenodd">${TAP}</g><g class="ta-easy" fill-rule="evenodd">${EASY}</g>` },
    lockup:{ vb:"0 0 770.2 335.3", w:770.2, h:335.3, body:()=> `<g transform="translate(276.65 0)"><g class="ta-mark" fill-rule="evenodd">${MARK}</g></g><g transform="translate(0 154.7)"><g class="ta-tap" fill-rule="evenodd">${TAP}</g><g class="ta-easy" fill-rule="evenodd">${EASY}</g></g>` },
    mark:{ vb:"0 0 200 134", w:200, h:134, body:()=> `<g class="ta-mark" fill-rule="evenodd">${MARK}</g>` },
  };
  const escA = s=> String(s == null ? "" : s).replace(/[&<>"']/g, c=>({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c]));
  /** chuỗi SVG nội tuyến; label rỗng → trang trí (aria-hidden) */
  function logoSVG(kind, cls, label){
    const k = KINDS[kind] || KINDS.wordmark;
    const a11y = label ? `role="img" aria-label="${escA(label)}"` : `aria-hidden="true"`;
    return `<svg xmlns="http://www.w3.org/2000/svg" class="ta-logo ta-${kind in KINDS ? kind : "wordmark"}${cls ? " " + escA(cls) : ""}" viewBox="${k.vb}" width="${k.w}" height="${k.h}" ${a11y} focusable="false">${k.body()}</svg>`;
  }
  /* bản 1 file (build-single-html.py) nhúng ảnh thành data: URI → nhận diện thêm theo lớp CSS của ảnh logo */
  const CLASS_KIND = [["splash-logo","lockup"], ["wl-tag-mark","mark"], ["brand-wm","wordmark"], ["wl-brand-img","wordmark"], ["auth-logo","wordmark"]];
  function kindOfImg(img){
    const k = kindOf(img.getAttribute("src")); if(k) return k;
    const c = " " + String(img.getAttribute("class") || "") + " ";
    for(const [cls, kind] of CLASS_KIND) if(c.includes(" " + cls + " ")) return kind;
    return "";
  }
  function kindOf(src){
    src = String(src || "");
    if(/assets\/brand\/logo-wordmark-(light|dark)\.svg(\?|#|$)/.test(src)) return "wordmark";
    if(/assets\/brand\/logo-lockup-(light|dark)\.svg(\?|#|$)/.test(src)) return "lockup";
    if(/assets\/brand\/logo-mark\.svg(\?|#|$)/.test(src)) return "mark";
    return "";
  }
  const SEL = 'img[src*="assets/brand/logo-wordmark-"], img[src*="assets/brand/logo-lockup-"], img[src*="assets/brand/logo-mark.svg"], img.brand-wm, img.wl-brand-img, img.wl-tag-mark, img.splash-logo, img.auth-logo';
  function skip(img){
    try{ return img.hasAttribute("data-ta-keep") || !!(img.closest && img.closest(".tsx, .adm, [data-ta-keep]")); }catch(e){ return true; }
  }
  /** thay mọi <img> logo trong root bằng SVG nội tuyến; trả về số logo đã thay */
  function swapLogos(root){
    if(OFF.logo) return 0;
    let n = 0;
    try{
      root = root || document;
      if(!root.querySelectorAll) return 0;
      const list = Array.from(root.querySelectorAll(SEL));
      for(const img of list){
        if(!img.parentNode || skip(img)) continue;
        const kind = kindOfImg(img); if(!kind) continue;
        const pairHidden = img.classList && img.classList.contains("on-light") && img.getAttribute("aria-hidden") === "true";
        if(pairHidden){                                          // bản nền sáng đi cặp: SVG nội tuyến đã tự đổi màu → gỡ
          const sib = img.parentNode.querySelector(".ta-logo");
          if(sib){ img.remove(); n++; }
          continue;
        }
        const cls = String(img.getAttribute("class") || "").replace(/\bon-dark\b/, "").trim();
        const label = img.getAttribute("aria-hidden") === "true" ? "" : (img.getAttribute("alt") || "");
        const tpl = document.createElement("template");
        tpl.innerHTML = logoSVG(kind, cls, label);
        const svg = tpl.content.firstElementChild; if(!svg) continue;
        const st = img.getAttribute("style"); if(st) svg.setAttribute("style", st);
        img.replaceWith(svg); n++;
        // ảnh cặp nằm SAU ảnh chính (menu, thanh trên, splash) → gỡ luôn
        const p = svg.parentNode;
        if(p && p.querySelectorAll) p.querySelectorAll('img.on-light[aria-hidden="true"]').forEach(x=>{ if(kindOfImg(x)) x.remove(); });
      }
    }catch(e){ try{ console.warn("[theme-accent] logo", e); }catch(_){} }
    return n;
  }
  /* token accent đang áp (đọc từ CSS) — dùng cho kiểm thử / công cụ */
  const TOKENS = ["--accent","--accent-2","--on-accent","--accent-soft","--accent-glow","--cta-bg","--cta-solid","--cta-fg","--link","--logo-mark","--logo-text"];
  function tokens(el){
    const out = {};
    try{ const cs = getComputedStyle(el || document.documentElement); TOKENS.forEach(k=> out[k] = String(cs.getPropertyValue(k) || "").trim()); }catch(e){}
    return out;
  }

  let queued = false;
  function queue(){
    if(queued) return; queued = true;
    const run = ()=>{ queued = false; swapLogos(document); };
    if(typeof requestAnimationFrame === "function") requestAnimationFrame(run); else setTimeout(run, 16);
  }
  function start(){
    swapLogos(document);
    try{
      if(typeof MutationObserver === "function" && document.body){
        new MutationObserver(muts=>{
          for(const m of muts){ for(const nd of m.addedNodes || []){ if(nd.nodeType === 1 && (nd.tagName === "IMG" || (nd.querySelector && nd.querySelector(SEL)))){ queue(); return; } } }
        }).observe(document.body, { childList:true, subtree:true });
      }
    }catch(e){}
  }
  window.teAccent = { logoSVG, swapLogos, tokens, kindOf, KINDS:Object.keys(KINDS), TOKENS, kindOfImg };
  if(document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})();
