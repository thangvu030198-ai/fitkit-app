/* =========================================================================
   TapEasy — ẢNH MINH HOẠ BÀI TẬP PHONG CÁCH RIÊNG (exercise-art.js)
   Nạp NGAY SAU people-ai.js (trước templates.js/app.js).
   - Ảnh do AI tạo từ mô tả chữ (workflow media-muse.yml → media/exercise-ai/), phong cách TapEasy:
     hình người xám graphite, cơ đang làm việc phát sáng xanh teal, nền navy (docs/EXERCISE-ART.md).
   - media/exercise-ai/index.json liệt kê ảnh đã có; id "ex-<key>" ↔ EXERCISES[key].
   - Có ảnh → EXERCISES[key].img = ảnh AI; danh sách bài dùng ảnh nhỏ (-sm) thay ảnh bìa video kho.
   - Chưa có / lỗi mạng → giữ ảnh cũ. Danh sách id lưu localStorage để lần mở sau đổi ngay từ đầu.
   ========================================================================= */
(function(G){
"use strict";
if(G.fkExArt) return;
const BASE = "https://tapeasy.app/media/exercise-ai/";
const LS = "fk_exart_idx";
let avail = new Set();

function ls(get, v){ try{ if(get) return localStorage.getItem(LS); localStorage.setItem(LS, v); }catch(e){ return null; } }
function keyOf(id){ return String(id || "").replace(/^ex-/, ""); }
function exs(){ try{ return typeof EXERCISES !== "undefined" ? EXERCISES : null; }catch(e){ return null; } }
function valid(e){ return e && typeof e.id === "string" && /^ex-[a-z0-9]+$/.test(e.id) && e.file === e.id + ".webp"; }

function apply(ids){
  const E = exs(); if(!E) return 0;
  let n = 0;
  ids.forEach(id=>{ const k = keyOf(id); if(E[k]){ if(!E[k]._origImg) E[k]._origImg = E[k].img; E[k].img = BASE + id + ".webp"; avail.add(k); n++; } });
  return n;
}
function swapDom(){
  if(typeof document === "undefined") return;
  document.querySelectorAll("img[data-exart]").forEach(im=>{
    const k = im.getAttribute("data-exart");
    if(avail.has(k) && im.src.indexOf("/exercise-ai/") < 0){ im.src = BASE + "ex-" + k + "-sm.webp"; }
  });
}
function load(){
  const cached = ls(true);
  if(cached){ try{ apply(JSON.parse(cached)); }catch(e){} }
  if(typeof fetch !== "function") return;
  fetch(BASE + "index.json", { cache: "no-cache" }).then(r=> r.ok ? r.json() : null).then(j=>{
    if(!Array.isArray(j)) return;
    const ids = j.filter(valid).map(e=> e.id);
    ls(false, JSON.stringify(ids));
    if(apply(ids)) swapDom();
  }).catch(()=>{});
}

G.fkExArt = {
  BASE,
  has: k=> avail.has(String(k || "")),
  /** ảnh nhỏ cho danh sách: item của buổi/giáo án (exerciseId) hoặc key */
  thumb(itemOrKey){
    const k = typeof itemOrKey === "string" ? itemOrKey : (itemOrKey && !itemOrKey.custom ? itemOrKey.exerciseId : "");
    return k && avail.has(k) ? BASE + "ex-" + k + "-sm.webp" : "";
  },
  full: k=> avail.has(k) ? BASE + "ex-" + k + ".webp" : "",
  isAi: u=> String(u || "").indexOf("/media/exercise-ai/") >= 0,
  _apply: apply, _keys: ()=> Array.from(avail),
};
load();
})(typeof window !== "undefined" ? window : globalThis);
