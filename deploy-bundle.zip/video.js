/* =========================================================================
   TapEasy — Thư viện video minh hoạ (Pexels + Pixabay)
   - Tìm video theo tên bài tập, xem trước, chọn để gắn vào:
       · bài trong giáo án cá nhân (item.stock)
       · bài PT giao cho học viên (exercise.stock + videoUrl)
       · xem nhanh trong thư viện 800+ bài
   - Video nền cho màn mở app
   - Luôn hiển thị nguồn + tác giả (điều kiện của Pexels/Pixabay API)
   Nạp SAU app.js / exdb.js, TRƯỚC coach.js.
   ========================================================================= */

state.mediaSettings = Object.assign({ pexelsKey:"", pixabayKey:"" }, state.mediaSettings || {});
const VID_CACHE_KEY = "fitkit_video_cache_v1";

function mediaKeys(){
  const cfg = (typeof MEDIA_CONFIG !== "undefined") ? MEDIA_CONFIG : {};
  return {
    pexels: (state.mediaSettings.pexelsKey || cfg.pexelsKey || "").trim(),
    pixabay: (state.mediaSettings.pixabayKey || cfg.pixabayKey || "").trim(),
  };
}
function hasVideoSource(){ const k = mediaKeys(); return !!(k.pexels || k.pixabay); }

/* ---- Tạo từ khoá tiếng Anh cho bài tập ---- */
const VID_MUSCLE_EN = {
  "Ngực":"chest workout", "Lưng":"back workout", "Vai":"shoulder press workout", "Chân":"leg workout squat",
  "Tay trước":"bicep curl", "Tay sau":"tricep workout", "Bụng":"abs workout", "Tim mạch":"cardio workout",
  "Toàn thân":"full body workout", "Đùi trước":"squat", "Đùi sau":"hamstring workout", "Mông":"glute workout",
  "Xô (lưng rộng)":"lat pulldown", "Bắp chân":"calf raise", "Cẳng tay":"forearm workout", "Cầu vai":"shrug workout",
};
const VID_VI_EN = [
  [/đẩy ngực|bench/i,"bench press"], [/chống đẩy|push/i,"push up"], [/kéo xà|pull-?up/i,"pull up"], [/gánh tạ|squat/i,"squat"],
  [/deadlift|nâng tạ từ sàn/i,"deadlift"], [/plank/i,"plank"], [/nhảy dây/i,"jump rope"], [/chạy/i,"running"],
  [/đạp xe/i,"cycling"], [/burpee/i,"burpee"], [/lunge|chùng chân/i,"lunges"], [/gập bụng|crunch/i,"crunches"],
  [/chèo|row/i,"rowing workout"], [/cuốn tay|curl/i,"bicep curl"], [/yoga|giãn cơ/i,"stretching"],
];
function videoQueryFor(meta){
  const name = String(meta && meta.name || "");
  const inParen = (name.match(/\(([A-Za-z][A-Za-z0-9 \-]+)\)/) || [])[1];
  if(inParen) return inParen.replace(/\b(DB|BB)\b/g,"").trim() + " exercise";
  if(/^[\x00-\x7F]+$/.test(name) && name.trim()) return name.trim() + " exercise";   // tên tiếng Anh (thư viện 800+)
  const hit = VID_VI_EN.find(([re])=> re.test(name)); if(hit) return hit[1];
  const m = String(meta && meta.muscle || "").split(",")[0].trim();
  return VID_MUSCLE_EN[m] || "gym workout";
}

/* Pixabay tìm theo thẻ → tên dài (VD "Barbell Bench Press - Medium Grip") thường ra 0 kết quả.
   Tạo chuỗi từ khoá từ cụ thể → chung, thử lần lượt tới khi có video. */
const VID_EN_KEYWORDS = [
  ["bench press"],["push up","push-up","pushup"],["pull up","pull-up","pullup","chin up","chin-up"],["lat pulldown","pulldown"],
  ["deadlift"],["squat"],["lunge","lunges"],["leg press"],["leg curl","hamstring curl"],["leg extension"],["calf raise","calf press"],
  ["hip thrust","glute bridge","bridge"],["bicep curl","biceps curl","hammer curl","curl"],["tricep","triceps","pushdown","kickback","skullcrusher"],
  ["shoulder press","overhead press","military press"],["lateral raise","front raise","rear delt"],["chest fly","fly","flye","pec deck"],
  ["row","rowing"],["shrug"],["dip","dips"],["plank"],["crunch","crunches","sit up","sit-up"],["russian twist","twist"],["leg raise"],
  ["burpee"],["jump rope","rope jumping","skipping"],["kettlebell"],["clean","snatch","jerk"],["stretch","stretching"],["yoga"],
  ["running","run","jog","sprint"],["cycling","bike"],["rowing machine","rower"],["box jump","jump"],
];
const VID_KW_QUERY = { "tricep":"arm workout", "triceps":"arm workout", "pushdown":"arm workout", "kickback":"arm workout", "skullcrusher":"arm workout",
  "deadlift":"deadlift", "row":"rowing exercise", "rowing":"rowing exercise", "curl":"bicep curl", "hammer curl":"bicep curl", "biceps curl":"bicep curl",
  "fly":"chest fly", "flye":"chest fly", "pec deck":"chest fly", "crunch":"abs workout", "crunches":"abs workout", "sit up":"abs workout", "sit-up":"abs workout",
  "twist":"abs workout", "leg raise":"abs workout", "plank":"plank", "dip":"dips", "shrug":"shoulder workout", "lateral raise":"shoulder workout",
  "front raise":"shoulder workout", "rear delt":"shoulder workout", "run":"running", "jog":"running", "sprint":"running", "bike":"cycling",
  "jump":"jumping exercise", "bridge":"glute bridge", "clean":"weightlifting", "snatch":"weightlifting", "jerk":"weightlifting", "stretch":"stretching" };
function videoQueriesFromString(q){
  const raw = String(q||"");
  let s = raw.replace(/\s+-\s.*$/,"").replace(/\(.*?\)/g,"").replace(/\bexercise\b/ig,"").replace(/\s+/g," ").trim();
  const low = (raw+" "+s).toLowerCase();
  let kw = null;
  for(const group of VID_EN_KEYWORDS){ const hit = group.find(k=> low.includes(k)); if(hit){ kw = VID_KW_QUERY[hit] || group[0]; break; } }
  const stripped = s.replace(/\b(barbell|dumbbells?|cable|machine|smith|kettlebells?|bands?|ez[- ]?bar|lever|weighted|alternating|alternate|seated|standing|lying|incline|decline|one[- ]arm|single[- ]arm|single[- ]leg|one[- ]leg|close[- ]grip|wide[- ]grip|reverse|medium grip|with|on|the|and)\b/gi,"").replace(/\s+/g," ").trim();
  const out = [];
  const short = s.split(" ").length<=3 ? s : null;
  // Thêm "exercise" làm Pixabay trả về video chung chung (chạy bộ, yoga…) → dùng từ khoá gọn trước
  [kw, stripped && stripped.split(" ").length<=3 ? stripped : null, short, kw && !/workout/.test(kw) && kw+" workout", "gym workout"].forEach(x=>{ if(x && !out.some(o=>o.toLowerCase()===x.toLowerCase())) out.push(x); });
  return out;
}

/* ---- Gọi API ---- */
function pickPexelsFile(files){
  const mp4 = (files||[]).filter(f=> (f.file_type||"").includes("mp4") && f.link);
  mp4.sort((a,b)=> Math.abs(Math.max(a.width,a.height)-1280) - Math.abs(Math.max(b.width,b.height)-1280));
  return mp4[0];
}
async function searchPexels(q, key, orientation){
  const u = `https://api.pexels.com/videos/search?query=${encodeURIComponent(q)}&per_page=15${orientation?`&orientation=${orientation}`:""}`;
  const r = await fetch(u, { headers:{ Authorization: key } });
  if(r.status===401 || r.status===403) throw new Error("Pexels: API key không hợp lệ");
  if(!r.ok) throw new Error("Pexels: lỗi " + r.status);
  const j = await r.json();
  return (j.videos||[]).map(v=>{ const f = pickPexelsFile(v.video_files); if(!f) return null;
    return { provider:"Pexels", id:"px"+v.id, url:f.link, thumb:v.image, w:f.width, h:f.height, duration:v.duration,
      author:(v.user&&v.user.name)||"Pexels", authorUrl:(v.user&&v.user.url)||"https://www.pexels.com", pageUrl:v.url }; }).filter(Boolean);
}
async function searchPixabay(q, key){
  const u = `https://pixabay.com/api/videos/?key=${encodeURIComponent(key)}&q=${encodeURIComponent(q)}&per_page=15&safesearch=true`;
  const r = await fetch(u);
  if(r.status===400 || r.status===401) throw new Error("Pixabay: API key không hợp lệ");
  if(!r.ok) throw new Error("Pixabay: lỗi " + r.status);
  const j = await r.json();
  return (j.hits||[]).map(h=>{ const V = h.videos || {}; const v = [V.tiny, V.small, V.medium].find(x=> x && x.url);   // "tiny" của Pixabay thường là 720p, 1–5MB — nhẹ cho điện thoại
    if(!v || !v.url) return null;
    return { provider:"Pixabay", id:"pb"+h.id, url:v.url, thumb: v.thumbnail || (h.picture_id ? `https://i.vimeocdn.com/video/${h.picture_id}_640x360.jpg` : ""),
      w:v.width, h:v.height, duration:h.duration, tags:(h.tags||"").toLowerCase(), author:h.user||"Pixabay", authorUrl:`https://pixabay.com/users/${h.user}-${h.user_id}/`, pageUrl:h.pageURL }; }).filter(Boolean);
}
function vidCacheGet(k){ try{ const c = JSON.parse(localStorage.getItem(VID_CACHE_KEY)||"{}")[k]; if(c && Date.now()-c.t < 7*86400000) return c.v; }catch(e){} return null; }
function vidCacheSet(k, v){ try{ const all = JSON.parse(localStorage.getItem(VID_CACHE_KEY)||"{}"); all[k] = { t:Date.now(), v }; const keys = Object.keys(all); if(keys.length>60) delete all[keys[0]]; localStorage.setItem(VID_CACHE_KEY, JSON.stringify(all)); }catch(e){} }

/* integrator (FIX-core vòng 2 #5): mất mạng → không gọi API video cho từng bài. Lỗi KẾT NỐI (không phải lỗi khoá/HTTP) được nhớ 60 s;
   navigator.onLine === false hoặc đang trong 60 s đó → báo lỗi ngay, không gửi request. Sự kiện "online" xoá nhớ lỗi. */
const VID_NET_MSG = "Không kết nối được tới máy chủ video — kiểm tra mạng", VID_NET_WAIT = 60e3;
let _vidNetFailAt = 0;
try{ if(typeof window !== "undefined" && typeof window.addEventListener === "function") window.addEventListener("online", ()=>{ _vidNetFailAt = 0; }); }catch(e){}
function vidNetBlocked(){
  try{ if(typeof navigator !== "undefined" && navigator && navigator.onLine === false) return true; }catch(e){}
  return !!_vidNetFailAt && Date.now() - _vidNetFailAt < VID_NET_WAIT;
}
async function searchVideos(q, opts={}){
  const keys = mediaKeys();
  if(!keys.pexels && !keys.pixabay) throw new Error("NO_KEY");
  const ck = `${q}|${opts.orientation||""}|${keys.pexels?1:0}${keys.pixabay?1:0}`;
  const cached = vidCacheGet(ck); if(cached) return cached;
  if(vidNetBlocked()) throw new Error(VID_NET_MSG);
  const jobs = [];
  if(keys.pexels) jobs.push(searchPexels(q, keys.pexels, opts.orientation).catch(e=>({ err:e.message })));
  if(keys.pixabay) jobs.push(searchPixabay(q, keys.pixabay).catch(e=>({ err:e.message })));
  const res = await Promise.all(jobs);
  const errs = res.filter(r=>r && r.err).map(r=> /failed to fetch|networkerror|load failed/i.test(r.err) ? VID_NET_MSG : r.err);
  const lists = res.filter(Array.isArray);
  if(!lists.length && errs.length && errs.every(m=> m === VID_NET_MSG)) _vidNetFailAt = Date.now();   // mọi nguồn lỗi kết nối → nhớ 60 s
  else if(lists.length) _vidNetFailAt = 0;
  const out = [];   // xen kẽ 2 nguồn
  for(let i=0; i<15; i++) lists.forEach(l=>{ if(l[i]) out.push(l[i]); });
  if(!out.length && errs.length) throw new Error(errs.join(" · "));
  vidCacheSet(ck, out);
  return out;
}

/* ---- HTML video + dòng ghi nguồn ---- */
function stockVideoHTML(stock, opts={}){
  if(!stock || !stock.url) return "";
  return `<div class="stock-wrap" style="${opts.noMargin?"":"margin-bottom:14px;"}">
    <video class="stock-video" src="${attrUrl(stock.url)}" ${stock.thumb?`poster="${attrUrl(stock.thumb)}"`:""} autoplay muted loop playsinline preload="metadata" style="max-height:${opts.maxHeight||"38vh"}"></video>
    ${stockCreditHTML(stock)}
  </div>`;
}
/* href an toàn: chỉ http(s) (chặn javascript:, data:…) — BUG-02 */
function vHref(u, fallback){ const s = String(u||"").trim(); return escapeHtml(/^https?:\/\//i.test(s) ? s : (fallback || "#")); }
function stockCreditHTML(s){
  if(!s) return "";
  if(s.provider==="YMove") return `<div class="stock-credit">Exercise video by <a href="https://ymove.app/exercise-api" target="_blank" rel="noopener">Your Move</a></div>`;
  if(s.provider==="wger") return `<div class="stock-credit">Video: <a href="${vHref(s.pageUrl, "https://wger.de")}" target="_blank" rel="noopener">${escapeHtml(String(s.author||"").split(" · ")[0])} / wger.de</a> · <a href="${vHref(s.authorUrl, "https://creativecommons.org/licenses/by-sa/4.0/")}" target="_blank" rel="noopener">CC BY-SA 4.0</a> · đã nén lại</div>`;
  if(s.provider==="FIT KIT" || s.provider==="TapEasy") return `<div class="stock-credit">Video minh hoạ tạo bằng AI · TapEasy — tham khảo động tác, ưu tiên hướng dẫn của PT</div>`;   // "FIT KIT" = khoá dữ liệu cũ trong media/extra/index.json
  if(s.provider==="Pexels") return `<div class="stock-credit">Video: <a href="${vHref(s.pageUrl, "https://www.pexels.com")}" target="_blank" rel="noopener">Pexels</a> · <a href="https://www.pexels.com/license/" target="_blank" rel="noopener">Pexels License</a></div>`;
  if(s.provider==="Wikimedia Commons") return `<div class="stock-credit">Video: <a href="${vHref(s.pageUrl, "https://commons.wikimedia.org")}" target="_blank" rel="noopener">${escapeHtml(s.author||"")} / Wikimedia Commons</a>${s.license?` · ${s.authorUrl?`<a href="${vHref(s.authorUrl)}" target="_blank" rel="noopener">${escapeHtml(s.license)}</a>`:escapeHtml(s.license)}`:""} · đã cắt & nén</div>`;
  return `<div class="stock-credit">Video: <a href="${vHref(s.authorUrl||s.pageUrl)}" target="_blank" rel="noopener">${escapeHtml(s.author||"")}</a> / <a href="${vHref(s.pageUrl)}" target="_blank" rel="noopener">${escapeHtml(s.provider||"")}</a></div>`;
}
function stockFromVideo(v){ return { url:v.url, thumb:v.thumb, provider:v.provider, author:v.author, authorUrl:v.authorUrl, pageUrl:v.pageUrl, license:v.license||"" }; }

/* ---- Sheet chọn video ---- */
function openVideoPicker(query, onPick, opts={}){
  let q = query || "gym workout", preview = null;
  const render = (bodyHtml)=>{
    openSheet(`
      <div class="sheet-header"><h3>${escapeHtml(opts.title || "Video minh hoạ")}</h3><button class="icon-btn" id="vp-close"><span class="material-symbols-rounded">${opts.onBack?"arrow_back":"close"}</span></button></div>
      <div class="search-box" style="margin-bottom:10px;"><span class="material-symbols-rounded" style="color:var(--text-dim);">search</span>
        <input id="vp-q" value="${escapeHtml(q)}" placeholder="Từ khoá tiếng Anh — VD: squat, push up"></div>
      <div id="vp-body">${bodyHtml||`<div class="vp-loading"><div class="spinner"></div></div>`}</div>
      <p class="small-note" style="text-align:center;margin-top:8px;">Video miễn phí từ Pexels &amp; Pixabay · luôn ghi nguồn tác giả</p>
    `);
    $("#vp-close").addEventListener("click", ()=> opts.onBack ? opts.onBack() : closeSheet());
    $("#vp-q").addEventListener("keydown", e=>{ if(e.key==="Enter"){ q = e.target.value.trim() || q; load(); } });
  };
  const load = async ()=>{
    render();
    try{
      let list = [];
      for(const qq of videoQueriesFromString(q)){ list = await searchVideos(qq, { orientation: opts.orientation }); if(list.length) break; }
      if(!$("#vp-body")) return;
      $("#vp-body").innerHTML = list.length ? `<div class="vp-grid">${list.map((v,i)=>`
        <button class="vp-item" data-vi="${i}">
          <img src="${escapeHtml(v.thumb||"")}" loading="lazy" alt="" onerror="this.style.opacity=0">
          <span class="vp-dur">${Math.round(v.duration||0)}s</span><span class="vp-src">${escapeHtml(v.provider||"")}</span>
        </button>`).join("")}</div>` : `<p class="empty-hint">Không tìm thấy video cho "${escapeHtml(q)}". Thử từ khoá khác.</p>`;
      $$("[data-vi]").forEach(b=> b.addEventListener("click", ()=>{ preview = list[Number(b.dataset.vi)]; showPreview(); }));
    }catch(e){
      if(!$("#vp-body")) return;
      if(e.message==="NO_KEY"){ $("#vp-body").innerHTML = noKeyHTML(); bindNoKey(); }
      else $("#vp-body").innerHTML = `<p class="empty-hint">${escapeHtml(e.message)}<br>Kiểm tra kết nối mạng hoặc API key.</p>`;
    }
  };
  const showPreview = ()=>{
    $("#vp-body").innerHTML = `
      ${stockVideoHTML(stockFromVideo(preview), { maxHeight:"46vh" })}
      ${onPick ? `<button class="btn btn-primary btn-block" id="vp-use"><span class="material-symbols-rounded">check</span>Dùng video này</button>` : ""}
      <button class="btn btn-ghost btn-block" id="vp-back" style="margin-top:6px;">Chọn video khác</button>`;
    $("#vp-back").addEventListener("click", load);
    const use = $("#vp-use"); if(use) use.addEventListener("click", ()=>{ onPick(stockFromVideo(preview)); });
  };
  const bindNoKey = ()=>{ const b = $("#vp-setkey"); if(b) b.addEventListener("click", ()=> openMediaSettings(()=> openVideoPicker(query, onPick, opts))); };
  load();
}
function noKeyHTML(){
  return `<div class="card" style="text-align:center;">
    <span class="material-symbols-rounded" style="font-size:36px;color:var(--mint);">video_library</span>
    <p style="margin-top:8px;">Chưa kết nối nguồn video.</p>
    <p class="small-note" style="margin-top:6px;">Thêm API key miễn phí của Pexels hoặc Pixabay để tìm hàng nghìn video tập luyện dùng thương mại được.</p>
    <button class="btn btn-primary btn-block" id="vp-setkey" style="margin-top:12px;">Kết nối nguồn video</button>
  </div>`;
}

/* ---- Cài đặt nguồn video ---- */
function openMediaSettings(onSaved){
  const cfg = (typeof MEDIA_CONFIG !== "undefined") ? MEDIA_CONFIG : {};
  const ms = state.mediaSettings;
  openSheet(`
    <div class="sheet-header"><h3>Nguồn video minh hoạ</h3><button class="icon-btn" onclick="closeSheet()"><span class="material-symbols-rounded">close</span></button></div>
    <p class="small-note">Theo tài liệu của bạn: Pexels &amp; Pixabay cho phép dùng thương mại miễn phí. Mỗi nguồn cần 1 API key. Hiện nên dùng <b>Pixabay</b> (đăng ký miễn phí ~2 phút) vì Pexels đang tạm dừng cấp key mới.</p>
    ${cfg.pexelsKey || cfg.pixabayKey ? `<p class="small-note" style="color:var(--mint);margin-top:6px;">Chủ app đã cài sẵn key cho mọi người dùng. Ô dưới chỉ để ghi đè trên máy này.</p>` : ""}
    <div class="field" style="margin-top:12px;"><label>Pixabay API key — lấy tại pixabay.com/api/docs</label><input id="ms-pb" value="${escapeHtml(ms.pixabayKey)}" placeholder="${cfg.pixabayKey?"(đang dùng key của chủ app)":"Dán key Pixabay"}" autocomplete="off"></div>
    <div class="field" style="margin-top:10px;"><label>Pexels API key (Pexels đang tạm dừng cấp key mới)</label><input id="ms-px" value="${escapeHtml(ms.pexelsKey)}" placeholder="${cfg.pexelsKey?"(đang dùng key của chủ app)":"Dán key Pexels"}" autocomplete="off"></div>
    <p class="auth-err" id="ms-err"></p>
    <button class="btn btn-primary btn-block" id="ms-save" style="margin-top:6px;">Lưu &amp; thử tìm video</button>
    <p class="small-note" style="margin-top:10px;">Key chỉ lưu trên máy này. Video luôn hiển thị tên tác giả và nguồn theo điều khoản của Pexels/Pixabay.</p>
  `);
  $("#ms-save").addEventListener("click", async ()=>{
    ms.pexelsKey = $("#ms-px").value.trim(); ms.pixabayKey = $("#ms-pb").value.trim();
    saveState();
    if(!hasVideoSource()){ closeSheet(); toast("Đã xoá key nguồn video"); return; }
    const btn = $("#ms-save"); btn.disabled = true; btn.textContent = "Đang thử...";
    try{
      localStorage.removeItem(VID_CACHE_KEY);
      const r = await searchVideos("squat exercise");
      toast(`Kết nối thành công · ${r.length} video mẫu`, "check_circle");
      if(onSaved) onSaved(); else closeSheet();
    }catch(e){ $("#ms-err").textContent = e.message==="NO_KEY" ? "Chưa có key." : e.message; btn.disabled = false; btn.textContent = "Lưu & thử tìm video"; }
  });
}

/* =====================================================================
   GẮN VÀO CÁC MÀN HIỆN CÓ
   ===================================================================== */

/* ---- Khối video phát ngay: ảnh bìa + nút play + dải video khác ----
   opts.stock   : video đã gắn sẵn (ưu tiên)
   opts.onSave  : (stock)=>{} — hiện nút "Gắn video này cho bài"
   opts.compact : bớt khoảng cách                                        */
let _vbSeq = 0;
function videoBlockHTML(){ const id = "vb" + (++_vbSeq); return { id, html:`<div class="vblock" id="${id}"><div class="vplayer skeleton"><div class="spinner"></div></div></div>` }; }
function fmtDur(s){ s = Math.round(s||0); return `${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`; }

async function mountVideoBlock(id, query, opts={}){
  const host = document.getElementById(id); if(!host) return;
  let list = [];
  if(opts.stock && opts.stock.url) list.push(Object.assign({ duration:opts.stock.duration||0 }, opts.stock, { _saved:true }));
  // 1) Video hướng dẫn đúng bài (YMove / wger) — ưu tiên tuyệt đối
  try{
    if(typeof findFreeExerciseVideos==="function"){
      const free = await findFreeExerciseVideos(opts.meta || opts.name || (Array.isArray(query) ? query[0] : query));   // meta có dụng cụ → lọc đúng video (BUG-07)
      free.forEach(v=>{ if(!list.some(x=>x.url===v.url)) list.push(Object.assign({ _guide:true }, v)); });
    }
  }catch(e){}
  // 2) Không có video hướng dẫn → video tham khảo từ Pixabay
  try{
    if(hasVideoSource() && !list.some(x=>x._guide)){
      const qs = Array.isArray(query) ? query : videoQueriesFromString(query);
      for(const q of qs){
        const found = await searchVideos(q);
        found.forEach(v=>{ if(!list.some(x=>x.url===v.url)) list.push(v); });
        if(list.length >= 4) break;
      }
      // Ưu tiên video có thẻ (tags) khớp từ khoá bài tập
      const words = String(qs[0]||"").toLowerCase().split(/\s+/).filter(w=> w.length>2 && !["exercise","workout","gym"].includes(w));
      const score = v=> v._saved ? 99 : words.filter(w=> (v.tags||"").includes(w)).length;
      list.sort((a,b)=> score(b)-score(a));
      // Chỉ giữ video tham khảo thật sự liên quan (có thẻ khớp tên bài + thẻ thể thao) — không hiện video ngẫu nhiên
      const sporty = v=> /exercise|workout|fitness|gym|training|sport|athlete|crossfit|run|jog|yoga|stretch/.test(v.tags||"");
      list = list.filter(v=> v._saved || v._guide || (score(v) > 0 && sporty(v)));
    }
  }catch(e){ if(!list.length){ host.innerHTML = `<div class="vb-msg"><span class="material-symbols-rounded">videocam</span>${escapeHtml(e.message==="NO_KEY" ? "Chưa kết nối nguồn video." : e.message)}</div>`; return; } }
  if(!document.getElementById(id)) return;
  if(!list.length){ host.innerHTML = hasVideoSource() ? `<div class="vb-msg"><span class="material-symbols-rounded">videocam</span>Chưa tìm thấy video cho bài này.</div>` : `<div class="vb-msg"><span class="material-symbols-rounded">videocam</span>Chưa kết nối nguồn video.</div>`; return; }
  let cur = 0;
  const draw = ()=>{
    const v = list[cur];
    host.innerHTML = `
      <div class="vplayer" data-state="idle">
        <video playsinline preload="metadata" ${v.thumb?`poster="${attrUrl(v.thumb)}"`:""} src="${attrUrl(v.url)}"></video>
        <button class="vp-play" aria-label="Phát video"><span class="material-symbols-rounded">play_arrow</span></button>
        <span class="vp-time">${fmtDur(v.duration)}</span>
        ${v._saved ? `<span class="vp-saved">Đã gắn cho bài</span>` : (v._guide || v.provider==="YMove" || v.provider==="wger") ? `<span class="vp-saved guide">Video hướng dẫn</span>` : `<span class="vp-saved ref">Video tham khảo</span>`}
      </div>
      <div class="vb-foot">${stockCreditHTML(v)}${opts.onSave && !v._saved ? `<button class="vb-save" type="button"><span class="material-symbols-rounded">check</span>Gắn video này</button>` : ""}</div>
      ${list.length > 1 ? `<div class="vthumbs">${list.slice(0,8).map((x,i)=>`
        <button class="vthumb ${i===cur?'on':''}" data-vt="${i}" aria-label="Video ${i+1}">
          ${x.thumb ? `<img src="${attrUrl(x.thumb)}" alt="" loading="lazy">` : ""}<span class="material-symbols-rounded">play_arrow</span><i>${fmtDur(x.duration)}</i>
        </button>`).join("")}</div>` : ""}`;
    const box = host.querySelector(".vplayer"), vid = box.querySelector("video");
    const start = ()=>{
      box.dataset.state = "playing"; vid.controls = true; vid.muted = false;
      const p = vid.play(); if(p && p.catch) p.catch(()=>{ vid.muted = true; vid.play().catch(()=>{}); });
    };
    box.querySelector(".vp-play").addEventListener("click", start);
    vid.addEventListener("click", ()=>{ if(box.dataset.state==="idle") start(); });
    vid.addEventListener("error", ()=>{
      box.dataset.state = "error";
      box.insertAdjacentHTML("beforeend", `<div class="vp-err">Không phát được video này. <a href="${vHref(v.pageUrl||v.url)}" target="_blank" rel="noopener">Mở trên ${escapeHtml(v.provider||"web")}</a></div>`);
    });
    $$("[data-vt]", host).forEach(b=> b.addEventListener("click", ()=>{ cur = Number(b.dataset.vt); draw(); const nb = host.querySelector(".vplayer"); if(nb) nb.querySelector(".vp-play").click(); }));
    const sv = host.querySelector(".vb-save");
    if(sv) sv.addEventListener("click", ()=>{ const st = stockFromVideo(list[cur]); st.duration = list[cur].duration; opts.onSave(st); list.forEach(x=>delete x._saved); list[cur]._saved = true; draw(); toast("Đã gắn video cho bài", "videocam"); });
  };
  draw();
}
/* Dừng video khi đóng bảng trượt */
const _closeSheetV1 = closeSheet;
closeSheet = function(){ $$("#sheet-content video").forEach(v=>{ try{ v.pause(); }catch(e){} }); _closeSheetV1(); };

/* 1. Giáo án cá nhân: chi tiết bài + khi đang tập */
const _openExerciseDetailV1 = openExerciseDetail;
openExerciseDetail = function(itemUid, isToday){
  _openExerciseDetailV1(itemUid, isToday);
  const item = getActivePlan().days[state.selectedDay].items.find(it=>it.uid===itemUid); if(!item) return;
  const meta = getExerciseMeta(item);
  const sheet = $("#sheet-content");
  const vb = videoBlockHTML();
  const wrap = document.createElement("div"); wrap.innerHTML = vb.html;
  if(!item.clipId){ const img = sheet.querySelector("img"); if(img) img.replaceWith(wrap.firstElementChild); else sheet.prepend(wrap.firstElementChild); }
  else { const after = $("#btn-fit-toggle-detail") || sheet.querySelector("video"); (after||sheet.firstElementChild).after(wrap.firstElementChild); }
  mountVideoBlock(vb.id, videoQueryFor(meta), { name:meta.name, meta, stock:item.stock, onSave: st=>{ item.stock = st; saveState(); renderWorkoutScreen(); } });
};
const _renderSessionStepV1 = renderSessionStep;
renderSessionStep = function(){
  _renderSessionStepV1();
  if(!session || session.idx >= session.items.length) return;
  const item = session.items[session.idx];
  if(item && !item.clipId){
    const img = $("#sheet-content img"); if(!img) return;
    const vb = videoBlockHTML(); const w = document.createElement("div"); w.innerHTML = vb.html; img.replaceWith(w.firstElementChild);
    const sm = getExerciseMeta(item);
    mountVideoBlock(vb.id, videoQueryFor(sm), { name:sm.name, meta:sm, stock:item.stock, onSave: st=>{ item.stock = st; saveState(); } });
  }
};

/* 2. Thư viện 800+ bài (bảng chọn bài): video ngay dưới ảnh */
const _openExDbDetailV1 = openExDbDetail;
openExDbDetail = function(ex, onBack){
  _openExDbDetailV1(ex, onBack);
  const anim = $("#exdb-anim"); if(!anim) return;
  const vb = videoBlockHTML(); anim.insertAdjacentHTML("beforebegin", vb.html);
  anim.classList.add("exdb-anim-small");
  mountVideoBlock(vb.id, ex.name + " exercise", { name:ex.name, meta:{ name:ex.name, equipment:ex.equipment||"" } });
};

/* 3. Màn mở app: video nền
   QT-12: chỉ phát khi màn chào (#auth.open) đang hiển thị — vào app là dừng, bỏ src (ngừng giải mã/tải)
   QU-34: không tự phát khi bật giảm chuyển động / tiết kiệm dữ liệu; có nút tạm dừng 44 px */
let _wlObs = null, _wlIO = null, _wlVis = null;
function welcomeOpen(){ const a = document.getElementById("auth"); return !!(a && a.classList.contains("open")); }
function welcomeVideoAllowed(){
  try{ if(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) return false; }catch(e){}
  try{ const c = navigator.connection; if(c && (c.saveData || /(^|-)2g$/.test(String(c.effectiveType||"")))) return false; }catch(e){}
  return true;
}
function stopWelcomeVideo(){
  $$(".wl-hero-video").forEach(v=>{ try{ v.pause(); v.removeAttribute("src"); v.load(); }catch(e){} v.remove(); });
  $$(".wl-vid-toggle").forEach(b=> b.remove());
  try{ if(_wlObs) _wlObs.disconnect(); }catch(e){} _wlObs = null;
  try{ if(_wlIO) _wlIO.disconnect(); }catch(e){} _wlIO = null;
  try{ if(_wlVis) document.removeEventListener("visibilitychange", _wlVis); }catch(e){} _wlVis = null;
}
function watchWelcomeVideo(vid, hero){
  const auth = document.getElementById("auth");
  if(auth && typeof MutationObserver === "function"){
    _wlObs = new MutationObserver(()=>{ if(!welcomeOpen()) stopWelcomeVideo(); });
    _wlObs.observe(auth, { attributes:true, attributeFilter:["class"] });
  }
  /* cuộn khỏi khung hero (trong trang chào dài) → tạm dừng giải mã */
  if(typeof IntersectionObserver === "function"){
    _wlIO = new IntersectionObserver(es=> es.forEach(e=>{ if(vid.dataset.user === "paused") return; if(e.isIntersecting) vid.play().catch(()=>{}); else vid.pause(); }), { threshold:0.05 });
    _wlIO.observe(hero);
  }
  _wlVis = ()=>{ if(document.hidden) vid.pause(); else if(welcomeOpen() && vid.dataset.user !== "paused") vid.play().catch(()=>{}); };
  document.addEventListener("visibilitychange", _wlVis);
}
async function mountWelcomeVideo(){
  const hero = $(".wl-hero"); if(!hero || hero.querySelector(".wl-hero-video")) return;
  if(!welcomeVideoAllowed() || !welcomeOpen()) return;
  const cfg = (typeof MEDIA_CONFIG !== "undefined") ? MEDIA_CONFIG : {};
  let src = "", credit = null;
  if(cfg.welcomeVideo && cfg.welcomeVideo !== "auto") src = cfg.welcomeVideo;
  else if(hasVideoSource()){
    try{
      const list = await searchVideos(cfg.welcomeQuery || "gym workout training", { orientation:"portrait" });
      const v = list.find(x=> x.h > x.w) || list[0];
      if(v){ src = v.url; credit = stockFromVideo(v); }
    }catch(e){}
  }
  if(!src || !$(".wl-hero") || !welcomeOpen() || hero.querySelector(".wl-hero-video")) return;   // người dùng đã vào app trong lúc chờ API
  const vid = document.createElement("video");
  vid.className = "wl-hero-video"; vid.src = src; vid.muted = true; vid.loop = true; vid.autoplay = true; vid.playsInline = true;
  vid.setAttribute("playsinline",""); vid.setAttribute("muted",""); vid.setAttribute("aria-hidden","true"); vid.preload = "metadata";
  vid.addEventListener("canplay", ()=> vid.classList.add("on"), { once:true });
  hero.insertBefore(vid, hero.querySelector(".wl-hero-shade"));
  vid.play().catch(()=>{});
  if(credit){ const c = document.createElement("div"); c.className = "wl-credit"; c.innerHTML = stockCreditHTML(credit); hero.appendChild(c); }
  const tg = document.createElement("button");
  tg.type = "button"; tg.className = "wl-vid-toggle"; tg.setAttribute("aria-label", "Tạm dừng video nền");
  tg.style.cssText = "position:absolute;z-index:4;right:16px;top:calc(64px + env(safe-area-inset-top));width:44px;height:44px;border-radius:50%;border:1px solid rgba(255,255,255,.28);background:rgba(6,26,36,.45);color:#fff;display:grid;place-items:center;";
  tg.innerHTML = `<span class="material-symbols-rounded">pause</span>`;
  tg.addEventListener("click", ()=>{
    const paused = vid.dataset.user === "paused";
    if(paused){ delete vid.dataset.user; vid.play().catch(()=>{}); } else { vid.dataset.user = "paused"; vid.pause(); }
    tg.setAttribute("aria-label", paused ? "Tạm dừng video nền" : "Phát video nền");
    tg.innerHTML = `<span class="material-symbols-rounded">${paused ? "pause" : "play_arrow"}</span>`;
  });
  hero.appendChild(tg);
  watchWelcomeVideo(vid, hero);
}
