/* 16/11/2026 — Ảnh minh hoạ bài tập phong cách TapEasy (exercise-art.js · media/exercise-ai) */
"use strict";
const { assert } = require("../lib/framework");
module.exports = {
  name: "Ảnh bài tập AI: gắn vào EXERCISES, ưu tiên ở danh sách, giữ ảnh cũ khi chưa có",
  area: "exercise-art.js",
  async define(t){
    const app = await t.app();
    t.test("EXART-01: module đã nạp; chưa có ảnh → thumb rỗng, ảnh cũ giữ nguyên", ()=>{
      assert.equal(app.ev(`typeof fkExArt`), "object");
      assert.equal(app.ev(`fkExArt.thumb("lunges")`), "");
      assert.ok(!/exercise-ai/.test(app.ev(`EXERCISES.lunges.img`)));
    });
    t.test("EXART-02: áp danh sách id → EXERCISES.img đổi sang ảnh AI; id lạ bị bỏ qua", ()=>{
      assert.equal(app.ev(`fkExArt._apply(["ex-benchpress","ex-squat","ex-khongco"])`), 2);
      assert.equal(app.ev(`EXERCISES.benchpress.img`), "https://tapeasy.app/media/exercise-ai/ex-benchpress.webp");
      assert.ok(app.ev(`!!EXERCISES.benchpress._origImg`));
      assert.equal(app.ev(`fkExArt.thumb({ exerciseId: "squat", custom: null })`), "https://tapeasy.app/media/exercise-ai/ex-squat-sm.webp");
      assert.equal(app.ev(`fkExArt.thumb({ exerciseId: "squat", custom: { name: "x" } })`), "", "bài tự tạo không đổi ảnh");
      assert.ok(app.ev(`fkExArt.isAi(EXERCISES.squat.img)`));
    });
    t.test("EXART-03: danh sách bài trong buổi dùng ảnh AI nhỏ thay ảnh bìa video kho", ()=>{
      const src = require("fs").readFileSync(require("path").join(__dirname, "..", "..", "app.js"), "utf8");
      assert.ok((src.match(/fkExArt\.thumb\(/g) || []).length >= 2 && /fkExArt\.full\(/.test(src));
      assert.ok(/data-exart=/.test(src));
    });
  }
};
